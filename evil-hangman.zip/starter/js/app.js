/**
 * This file will contain all of the Javascript "smarts" for our World Class Weather
 * app. The API key below will allow us to fetch up-to-date weather data from an
 * online service called Open Weather Map (http://openweathermap.org/). We'll be using
 * that data to populate our application.
 */
var API_KEY = "8e2d87f18292dd1305f3d6fbde147405";